#include <iostream>
using namespace std; // c++常规写法
int main() {
    cout << "Hello world!" <<endl;
    return 0;
}